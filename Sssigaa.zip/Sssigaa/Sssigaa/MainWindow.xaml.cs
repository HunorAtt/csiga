﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Sssigaa
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Random rnd = new Random();
        DispatcherTimer timer= new DispatcherTimer();
        int elsolepesek = 37;
        int masodiklepesek = 38;
        int harmadiklepesek = 35;
        string elso = "senki";
        string masodik = "senki";
        string harmadik = "senki";
        int elsoelsohelyezesei = 0;
        int masodikelsohelyezesei = 0;
        int harmadikelsohelyezesei = 0;
        int elsomasodikhelyezesei = 0;
        int masodikmasodikhelyezesei = 0;
        int harmadikmasodikhelyezesei = 0;
        int elsoharmadikhelyezesei = 0;
        int masodikharmadikhelyezesei = 0;
        int harmadikharmadikhelyezesei = 0;
        int elsopontjai = 0;
        int masodikpontjai = 0;
        int harmadikpontjai = 0;
        string elsohelyezes = "senki";
        string masodikhelyezes = "senki";
        string harmadikhelyezes = "senki";

        public MainWindow()
        {
            InitializeComponent();
            timer.Interval = TimeSpan.FromSeconds(0.001);
            timer.Tick += Timer_Tick;
        }
        private void kezdes_Click(object sender, RoutedEventArgs e)
        {
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            elsolepesek += rnd.Next(1, 10);
            if (elsolepesek > 716)
            {
                elsolepesek = 716;
                if (elso == "senki" || elso == "kötélcsiga")
                {
                    elso = "kötélcsiga";
                    elsomezo.Background = Brushes.Gold;
                    elsomezhely.Content = 1;
                    elsoelsohelyezesei++;
                    elsopontjai += 3;
                }
                else if (masodik == "senki" || masodik == "kötélcsiga")
                {
                    masodik = "kötélcsiga";
                    elsomezo.Background = Brushes.Silver;
                    elsomezhely.Content = 2;
                    elsomasodikhelyezesei++;
                    elsopontjai += 2;
                }
                else
                {
                    harmadik = "kötélcsiga";
                    elsomezo.Background = Brushes.Orange;
                    elsomezhely.Content = 3;
                    elsoharmadikhelyezesei++;
                    elsopontjai++;
                }
            }
            elsoversenyzo.Margin = new Thickness(elsolepesek, 65, 0, 0);
            masodiklepesek += rnd.Next(1, 10);
            if (masodiklepesek > 717)
            {
                masodiklepesek = 717;
                if (elso == "senki" || elso == "kakaóscsigák")
                {
                    elso = "kakaóscsigák";
                    masodikmezo.Background = Brushes.Gold;
                    masodikmezhely.Content = 1;
                    masodikelsohelyezesei++;
                    masodikpontjai += 3;
                }
                else if (masodik == "senki" || masodik == "kakaóscsigák")
                {
                    masodik = "kakaóscsigák";
                    masodikmezo.Background = Brushes.Silver;
                    masodikmezhely.Content = 2;
                    masodikmasodikhelyezesei++;
                    masodikpontjai += 2;
                }
                else
                {
                    harmadik = "kakaóscsigák";
                    masodikmezo.Background = Brushes.Orange;
                    masodikmezhely.Content = 3;
                    masodikharmadikhelyezesei++;
                    masodikpontjai++;
                }
            }
            masodikversenyzo.Margin = new Thickness(masodiklepesek, 147, 0, 0);
            harmadiklepesek += rnd.Next(1, 10);
            if (harmadiklepesek > 714)
            {
                harmadiklepesek = 714;
                if (elso == "senki" || elso == "búgócsiga")
                {
                    elso = "búgócsiga";
                    harmadikmezo.Background = Brushes.Gold;
                    harmadikmezhely.Content = 1;
                    harmadikelsohelyezesei++;
                    harmadikpontjai += 3;
                }
                else if (masodik == "senki" || masodik == "búgócsiga")
                {
                    masodik = "búgócsiga";
                    harmadikmezo.Background = Brushes.Silver;
                    harmadikmezhely.Content = 2;
                    harmadikmasodikhelyezesei++;
                    harmadikpontjai += 2;
                }
                else
                {
                    harmadik = "búgócsiga";
                    harmadikmezo.Background = Brushes.Orange;
                    harmadikmezhely.Content = 3;
                    harmadikharmadikhelyezesei++;
                    harmadikpontjai++;
                }
            }
            harmadikversenyzo.Margin = new Thickness(harmadiklepesek, 227, 0, 0);

            if (elsopontjai >= masodikpontjai && elsopontjai > harmadikpontjai)
                elsohelyezes = "elsocsiga";
            else if (elsopontjai < masodikpontjai && elsopontjai <= harmadikpontjai)
                masodikhelyezes = "elsocsiga";
            else
                harmadikhelyezes = "elsocsiga";

            if (masodikpontjai > elsopontjai && masodikpontjai >= harmadikpontjai)
                elsohelyezes = "masodikcsiga";
            else if (masodikpontjai <= elsopontjai && masodikpontjai < harmadikpontjai)
                masodikhelyezes = "masodikcsiga";
            else
                harmadikhelyezes = "masodikcsaiga";

            if (harmadikpontjai > elsopontjai && harmadikpontjai > masodikpontjai)
                elsohelyezes = "harmadik";
            else if (harmadikpontjai <= elsopontjai && harmadikpontjai < masodikpontjai)
                masodikhelyezes = "harmadik";
            else
                harmadikhelyezes = "harmadik";

            if (elsopontjai == masodikpontjai && elsopontjai == harmadikpontjai)
            {
                elsohelyezes = "elsocsiga";
                masodikhelyezes = "masodikcsiga";
                harmadikhelyezes = "harmadikcsiga";
            }

            adatok.Content = "helyezés név elsőhelyezések második helyezések harmadik helyezések pont";

            if (elsohelyezes == "elsocsiga")
                elsokiiras.Content = $"1. kötélcsiga {elsoelsohelyezesei} {elsomasodikhelyezesei} {elsoharmadikhelyezesei} {elsopontjai} pont";
            if (masodikhelyezes == "elsocsiga")
                elsokiiras.Content = $"2. kötélcsiga {elsoelsohelyezesei} {elsomasodikhelyezesei} {elsoharmadikhelyezesei} {elsopontjai} pont";
            if (harmadikhelyezes == "elsocsiga")
                elsokiiras.Content = $"3. kötélcsiga {elsoelsohelyezesei} {elsomasodikhelyezesei} {elsoharmadikhelyezesei} {elsopontjai} pont";

            if (elsohelyezes == "masodikcsiga")
                elsokiiras.Content = $"1. kakaóscsigák {masodikelsohelyezesei} {masodikmasodikhelyezesei} {masodikharmadikhelyezesei} {masodikpontjai} pont";
            if (masodikhelyezes == "masodikcsiga")
                elsokiiras.Content = $"2. kakaóscsigák {masodikelsohelyezesei} {masodikmasodikhelyezesei} {masodikharmadikhelyezesei} {masodikpontjai} pont";
            if (harmadikhelyezes == "masodikcsiga")
                elsokiiras.Content = $"3. kakaóscsigák {masodikelsohelyezesei} {masodikmasodikhelyezesei} {masodikharmadikhelyezesei} {masodikpontjai} pont";

            if (elsohelyezes == "harmadikcsiga")
                elsokiiras.Content = $"1. kakaóscsigák {harmadikelsohelyezesei} {harmadikmasodikhelyezesei} {harmadikharmadikhelyezesei} {harmadikpontjai} pont";
            if (masodikhelyezes == "harmadikcsiga")
                elsokiiras.Content = $"2. kakaóscsigák {harmadikelsohelyezesei} {harmadikmasodikhelyezesei} {harmadikharmadikhelyezesei} {harmadikpontjai} pont";
            if (harmadikhelyezes == "harmadikcsiga")
                elsokiiras.Content = $"3. kakaóscsigák {harmadikelsohelyezesei} {harmadikmasodikhelyezesei} {harmadikharmadikhelyezesei} {harmadikpontjai} pont";
        }
    }
}
